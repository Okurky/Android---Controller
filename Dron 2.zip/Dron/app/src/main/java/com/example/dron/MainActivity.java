package com.example.dron;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.google.android.gms.awareness.Awareness;
import com.google.android.gms.awareness.snapshot.WeatherResult;
import com.google.android.gms.awareness.state.Weather;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;

public class MainActivity extends AppCompatActivity {

    MyCanvas canvas;
    float x1, x2, y1, y2;
    int batteryLevel =70;
    android.content.Context cont;
    private final String TAG = getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        super.onCreate(savedInstanceState);
        canvas = new MyCanvas(this);
        lowBatteryNotification();
        dronConnected();
        setContentView(canvas);

/*
        GoogleApiClient client = new GoogleApiClient.Builder(cont)
                .addApi(Awareness.API)
                .build();
        client.connect();

        try{

            Awareness.SnapshotApi.getWeather(client)
                 .setResultCallback(new ResultCallback<WeatherResult>() {
                    @Override
                    public void onResult(@NonNull WeatherResult weatherResult) {
                            if (weatherResult.getStatus().isSuccess()) {
                              Weather weather = weatherResult.getWeather();
                                 weather.getConditions();
                                 weather.getTemperature(Weather.CELSIUS);
                            }
                    }
                });
        } catch (SecurityException e) {
             e.printStackTrace();
        }
*/
    }


   // public boolean sucessul(){ }

    private void lowBatteryNotification(){

        NotificationCompat.Builder ncbuilder=new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.jirik)
                .setContentText("Your dron´s battery level is getting low!!!");

        Intent  notIntent = new Intent (this, MainActivity.class);
        PendingIntent pIntent = PendingIntent.getActivity(this,0,notIntent,PendingIntent.FLAG_UPDATE_CURRENT);
        ncbuilder.setContentIntent(pIntent);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0,ncbuilder.build());

    }

    private void dronConnected(){

        NotificationCompat.Builder ncbuilder2=new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.jirik)
                .setContentText("Your dron is connected to this device!!");

        Intent  notIntent2 = new Intent (this, MainActivity.class);
        PendingIntent pIntent2 = PendingIntent.getActivity(this,0,notIntent2,PendingIntent.FLAG_UPDATE_CURRENT);
        ncbuilder2.setContentIntent(pIntent2);

        NotificationManager manager2 = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager2.notify(0,ncbuilder2.build());



    }
}



