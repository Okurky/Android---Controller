package com.example.dron;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import static android.graphics.Color.WHITE;

public class Data extends View {
    Paint paint;
    Bitmap horizon_bm, attidute_bm;
    int horizon_x,horizon_y,x_dir=1,y_dir=1,horizonHeight,horizonWidth,display_width,display_height,dron_attidute_width,dron_attidute_height,min=-90,max=90;
    String time;
    Random rand = new Random();
    int angle=0;
    public Data(Context context) {

        super(context);

        display_width= context.getResources().getDisplayMetrics().widthPixels;
        display_height = context.getResources().getDisplayMetrics().heightPixels;

        setBackgroundColor(WHITE);


        BitmapFactory.Options option=new BitmapFactory.Options();
        option.inJustDecodeBounds=true;
        BitmapFactory.decodeResource(getResources(),R.drawable.horizont,option);

        horizonHeight=option.outHeight;
        horizonWidth=option.outWidth;

        BitmapFactory.decodeResource(getResources(),R.drawable.dron_naklon,option);

        dron_attidute_height=option.outHeight;
        dron_attidute_width=option.outWidth;

        horizon_x=display_width/2-horizonWidth;
        horizon_y=display_height/2-horizonHeight;
    }
    protected void onDraw(Canvas canvas){

        Matrix matrix = new Matrix();


        System.out.println(canvas.getHeight()+"   "+((display_height/2)-dron_attidute_height)+"   "+((display_width/2)-dron_attidute_width));
        horizon_bm= BitmapFactory.decodeResource(getResources(),R.drawable.horizont);
        attidute_bm=BitmapFactory.decodeResource(getResources(),R.drawable.dron_naklon);

        System.out.println(horizon_y);

        Matrix rotator = new Matrix();

        int xRotate = 250+dron_attidute_width/2;
        int yRotate = 250+dron_attidute_height/2;

        rotator.postRotate(angle, xRotate, yRotate);
        System.out.println(xRotate+ " "+yRotate);

        int xTranslate = (display_width/2)-(250+dron_attidute_width/2);
        int yTranslate = (display_height/2)-(250+dron_attidute_height/2);

        rotator.postTranslate(xTranslate, yTranslate);

        Matrix rotator1 = new Matrix();

        int xRotate1 = 250+horizonWidth/2;
        int yRotate1 =250+horizonHeight/2;

        rotator1.postRotate(0, xRotate1, yRotate1);

        System.out.println(xRotate1+ " "+yRotate1);

        int xTranslate1 = (display_width/2)-(250+horizonWidth/2);
        int yTranslate1 = (display_height/2)-(250+horizonWidth/2);

        rotator1.postTranslate(xTranslate1, yTranslate1);
        System.out.println(xTranslate1+ " "+yTranslate1);

        time= new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPaint(paint);

        paint.setColor(Color.BLACK);
        paint.setTextSize(50);
        canvas.drawText(time, display_width/5, display_height/5, paint);



        canvas.drawBitmap(horizon_bm, rotator1, null);
        canvas.drawBitmap(attidute_bm, rotator, null);
        angle++;
        invalidate();
    }
    public static void moveUp(int moveDirection){
        moveDirection++;
    }
    public static void moveDown(int moveDirection){
        moveDirection--;
    }

}
